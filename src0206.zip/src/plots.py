import matplotlib.pyplot as plt
import numpy as np


########## sample 60000, mnist, non-iid ########## start #####

'''
N = 7
ind = np.arange(N)
width = 0.25

Train_Full = [ 0.872100,  0.872100,  0.872100,  0.872100,  0.872100,  0.872100,  0.872100]
bar1 = plt.bar(ind, Train_Full, width, color = 'r')

Train_Baseline = [0.8720, 0.8719, 0.8714, 0.8691, 0.8640, 0.8321, 0.7921]
bar2 = plt.bar(ind+width, Train_Baseline, width, color='g')

Train_Deltagrad = [0.8719, 0.8718, 0.8713, 0.8685, 0.8590, 0.8299, 0.7899]
bar3 = plt.bar(ind+width*2, Train_Deltagrad, width, color = 'b')

plt.xlabel("Deletion Ratio")
plt.ylabel('Test Accuracy')
plt.title("MNIST (non-IID)")

plt.ylim([0.65,0.9])

plt.xticks(ind+width,[0.001, 0.005, 0.01, 0.05, 0.1, 0.2, 0.3])
plt.legend( (bar1, bar2, bar3), ('Train_Full', 'Train_Baseline', 'Train_Deltagrad') )
plt.show()

'''




N = 7
ind = np.arange(N)
width = 0.25

Train_Full = [41.397,41.397,41.397,41.397,41.397,41.397, 41.397]
bar1 = plt.bar(ind, Train_Full, width, color = 'r')

Train_Baseline = [41.375, 41.253, 40.790, 39.239,37.416,32.981,29.659]
bar2 = plt.bar(ind+width, Train_Baseline, width, color='g')

Train_Deltagrad = [12.794, 12.817, 12.886,13.993,15.358,18.203,20.882]
bar3 = plt.bar(ind+width*2, Train_Deltagrad, width, color = 'b')

# plt.ylim([0,50])
plt.xlabel("Deletion Ratio")
plt.ylabel('Time Consumption')
plt.title("MNIST (non-IID)")

# plt.ylim([0.87,0.88])

plt.xticks(ind+width,[0.001, 0.005, 0.01, 0.05, 0.1, 0.2, 0.3])
plt.legend( (bar1, bar2, bar3), ('Train_Full', 'Train_Baseline', 'Train_Deltagrad') )
plt.show()



########## sample 60000, mnist, non-iid  ########## end #####
