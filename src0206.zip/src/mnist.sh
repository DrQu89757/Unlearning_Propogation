#!/bin/bash

function main() {
  # put all ratios you want to use in this array
  ALL_RATIOS=(0.001 0.005 0.01 0.05 0.1 0.2 0.3 )
  # if number of EPOCH_NUMBER changes, please change lrlen as well
  EPOCH_NUMBER=40

  # loop according to your ratio array
  for i in "${!ALL_RATIOS[@]}"; do
    PYTHON_CMD1="python generate_dataset_train_test.py --model Logistic_regression --dataset MNIST"
    PYTHON_CMD2="python generate_rand_delta_ids.py --dataset MNIST --ratio ${ALL_RATIOS[i]} --restart"
    # replace with your command here
    PYTHON_CMD3="python main.py --bz 16384 --epochs ${EPOCH_NUMBER} --model Logistic_regression --dataset MNIST --wd 0.0001 --lr 0.1 0.05 --lrlen 20 20 --train --ratio ${ALL_RATIOS[i]}"
    PYTHON_CMD4="python main.py --bz 16384 --epochs ${EPOCH_NUMBER} --model Logistic_regression --dataset MNIST --wd 0.0001 --lr 0.1 0.05 --lrlen 20 20 --method baseline --ratio ${ALL_RATIOS[i]}"
    PYTHON_CMD5="python main.py --bz 16384 --epochs ${EPOCH_NUMBER} --model Logistic_regression --dataset MNIST --wd 0.0001 --lr 0.1 0.05 --lrlen 20 20 --method deltagrad --period 5 --init 20 -m 2 --cached_size 20 --ratio ${ALL_RATIOS[i]}"


    $PYTHON_CMD1
    $PYTHON_CMD2
    $PYTHON_CMD3
    $PYTHON_CMD4
    $PYTHON_CMD5


    # for each ratio, loop for ten times
    # for j in {1..10}; do
      # $PYTHON_CMD1
      # $PYTHON_CMD2
      # $PYTHON_CMD3
      # $PYTHON_CMD4
      # $PYTHON_CMD5
    # done
  done
}

main > demo.log 2>&1 &

